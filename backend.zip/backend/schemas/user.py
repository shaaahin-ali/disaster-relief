from fastapi import APIRouter, Depends, status, HTTPException
from sqlalchemy.orm import Session
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.exc import IntegrityError

from database import get_db
from models.user import User
from schemas.user import UserCreate, ShowUser, UserOut
from auth.hashing import Hash
from auth.token import create_access_token
from dependencies.oauth2 import get_current_user

router = APIRouter()


# -------------------- LOGIN --------------------
@router.post("/login")
def login(
    request: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db)
):
    user = db.query(User).filter(User.email == request.username).first()

    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )

    if not Hash.verify(user.password, request.password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect password"
        )

    access_token = create_access_token(
        data={"sub": user.email, "role": user.role}
    )

    return {
        "access_token": access_token,
        "token_type": "bearer"
    }


# -------------------- SIGNUP --------------------
@router.post("/signup", response_model=ShowUser, status_code=status.HTTP_201_CREATED)
def signup(
    user: UserCreate,
    db: Session = Depends(get_db)
):
    try:
        # Check email
        existing_email = db.query(User).filter(User.email == user.email).first()
        if existing_email:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Email already registered"
            )

        # Check username
        existing_username = db.query(User).filter(User.username == user.username).first()
        if existing_username:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Username already taken"
            )

        # Password validation
        if len(user.password) < 6:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Password must be at least 6 characters long"
            )

        new_user = User(
            username=user.username,
            email=user.email,
            password=Hash.bcrypt(user.password),
            phone_number=user.phone_number,
            role=user.role
        )

        db.add(new_user)
        db.commit()
        db.refresh(new_user)

        return new_user

    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="User already exists"
        )


# -------------------- GET ALL USERS --------------------
@router.get("/users", response_model=list[ShowUser])
def get_users(
    db: Session = Depends(get_db),
    current_user: UserOut = Depends(get_current_user)
):
    return db.query(User).all()


# -------------------- GET CURRENT USER --------------------
@router.get("/users/me", response_model=UserOut)
def get_me(current_user: UserOut = Depends(get_current_user)):
    return current_user

from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class RequestCreate(BaseModel):
    title: str
    description: str
    location: str
    urgency_level: Optional[str] = "medium"  # low, medium, high

class ShowRequest(BaseModel):
    id: int
    title: str
    description: str
    location: str
    urgency_level: str
    status: str = "pending"  # pending, help_on_the_way, completed
    photo: Optional[str] = None
    timestamp: datetime
    user_id: int
    user_phone: Optional[str] = None  # Phone number of the user who created the request

    class Config:
        from_attributes = True

class VolunteerApplicationResponse(BaseModel):
    id: int
    volunteer_id: int
    request_id: int
    volunteer_name: str
    volunteer_phone: Optional[str] = None
    applied_at: datetime

    class Config:
        from_attributes = True

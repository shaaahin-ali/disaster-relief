from fastapi import APIRouter, Depends, status, HTTPException
from sqlalchemy.orm import Session
from schemas import user as schemas
import models.user as models
from models.user import User
from schemas.user import UserCreate, ShowUser
from auth.hashing import Hash
from sqlalchemy.exc import IntegrityError
from database import get_db
from fastapi.security import OAuth2PasswordRequestForm
from auth.token import create_access_token
from dependencies.oauth2 import get_current_user

router = APIRouter()


@router.post("/login")
def login(
    request: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db)
):
    user = db.query(models.User).filter(models.User.email == request.username).first()

    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )

    # Verify password
        if not Hash.verify(user.password, request.password):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Incorrect password"
        )

    token = create_access_token(data={"sub": user.email, "role": user.role})


    return {
        "access_token": token,
        "token_type": "bearer"
    }


@router.get("/users", response_model=list[schemas.ShowUser])
def get_users(
    db: Session = Depends(get_db),
    current_user: schemas.UserOut = Depends(get_current_user)
):
    """Get all users - requires authentication"""
    users = db.query(models.User).all()
    return users

@router.get("/users/me", response_model=schemas.UserOut)
def get_my_profile(current_user: schemas.UserOut = Depends(get_current_user)):
    return current_user

@router.post("/signup", response_model=ShowUser, status_code=status.HTTP_201_CREATED)
def create_user(user: UserCreate, db: Session = Depends(get_db)):
    try:
    # Check if email already exists
    db_user = db.query(User).filter(User.email == user.email).first()
    if db_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, 
            detail="Email already registered"
        )
    
    # Check if username already exists
    db_user = db.query(User).filter(User.username == user.username).first()
    if db_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Username already taken"
        )

    # Validate password length
    if len(user.password) < 6:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Password must be at least 6 characters long"
        )

    hashed_pwd = Hash.bcrypt(user.password)

    new_user = User(
        username=user.username,
        email=user.email,
        password=hashed_pwd,
        phone_number=user.phone_number,
        role=user.role
    )
        
        db.add(new_user)
        db.commit()
        db.refresh(new_user)
        
        # Return user with all required fields
        return ShowUser(
            id=new_user.id,
            username=new_user.username,
            email=new_user.email,
            role=new_user.role,
            phone_number=new_user.phone_number
        )
        
    except HTTPException:
        # Re-raise HTTP exceptions (like 400 errors)
        raise
    except IntegrityError as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, 
            detail="Email or username already exists"
        )
    except Exception as e:
        db.rollback()
        # Log the error for debugging
        import traceback
        error_trace = traceback.format_exc()
        print(f"Error creating user: {str(e)}")
        print(error_trace)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, 
            detail=f"Could not create user: {str(e)}"
        )

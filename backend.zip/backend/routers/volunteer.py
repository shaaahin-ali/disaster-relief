from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import Optional, List

from database import get_db
from models import volunteer_application as models
from models import request as request_models
from models import user as user_models
from schemas.user import UserOut
from schemas.request import VolunteerApplicationResponse, ShowRequest
from dependencies.roles import require_volunteer

router = APIRouter(
    prefix="/volunteer",
    tags=["Volunteers"]
)


@router.get("/dashboard")
def volunteer_dashboard(current_user: UserOut = Depends(require_volunteer)):
    return {"message": f"Welcome, volunteer {current_user.username}!"}


@router.post("/apply/{request_id}", status_code=status.HTTP_201_CREATED)
def apply_to_help(
    request_id: int,
    db: Session = Depends(get_db),
    current_user: UserOut = Depends(require_volunteer)
):
    req = db.query(request_models.Request).filter_by(id=request_id).first()
    if not req:
        raise HTTPException(status_code=404, detail="Request not found")

    if db.query(models.VolunteerApplication).filter_by(
        volunteer_id=current_user.id,
        request_id=request_id
    ).first():
        raise HTTPException(status_code=400, detail="Already applied")

    application = models.VolunteerApplication(
        volunteer_id=current_user.id,
        request_id=request_id
    )

    req.status = "help_on_the_way"

    db.add(application)
    db.commit()
    db.refresh(application)

    return {"message": "Application submitted"}


@router.get("/view-requests", response_model=List[ShowRequest])
def view_requests(
    location: Optional[str] = Query(None),
    db: Session = Depends(get_db),
    current_user: UserOut = Depends(require_volunteer)
):
    query = db.query(request_models.Request)

    if location:
        query = query.filter(request_models.Request.location.ilike(f"%{location}%"))

    return query.all()


@router.get("/request/{request_id}/volunteers", response_model=List[VolunteerApplicationResponse])
def get_request_volunteers(
    request_id: int,
    db: Session = Depends(get_db),
    current_user: UserOut = Depends(require_volunteer)
):
    applications = db.query(models.VolunteerApplication).filter_by(
        request_id=request_id
    ).all()

    result = []
    for app in applications:
        volunteer = db.query(user_models.User).filter_by(id=app.volunteer_id).first()
        result.append({
            "id": app.id,
            "volunteer_id": app.volunteer_id,
            "request_id": app.request_id,
            "volunteer_name": volunteer.username if volunteer else "Unknown",
            "volunteer_phone": volunteer.phone_number if volunteer else None,
            "applied_at": app.applied_at
        })

    return result

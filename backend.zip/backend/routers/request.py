# routers/request.py

from fastapi import APIRouter, Depends, HTTPException, status, Form, File, UploadFile
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from typing import Optional, List
import shutil
import os
from pathlib import Path

from database import get_db
from models.request import Request
from models.user import User

from schemas.request import ShowRequest, VolunteerApplicationResponse
from dependencies.oauth2 import get_current_user, verify_token

from config import settings

security = HTTPBearer(auto_error=False)

router = APIRouter(
    prefix="/request",
    tags=["Help Requests"]
)

# Ensure upload directory exists
os.makedirs(settings.UPLOAD_DIR, exist_ok=True)

def validate_file_upload(file: UploadFile) -> None:
    """Validate uploaded file type and size"""
    if not file:
        return
    
    # Check file extension
    file_ext = Path(file.filename).suffix.lower()
    if file_ext not in settings.ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"File type not allowed. Allowed types: {', '.join(settings.ALLOWED_EXTENSIONS)}"
        )
    
    # Check file size (read first chunk to check size)
    file.file.seek(0, os.SEEK_END)
    file_size = file.file.tell()
    file.file.seek(0)  # Reset file pointer
    
    if file_size > settings.MAX_UPLOAD_SIZE:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"File too large. Maximum size: {settings.MAX_UPLOAD_SIZE / 1024 / 1024}MB"
        )

def sanitize_filename(filename: str) -> str:
    """Sanitize filename to prevent path injection"""
    # Remove path components and keep only filename
    safe_name = Path(filename).name
    # Replace spaces and special chars
    safe_name = safe_name.replace(" ", "_")
    return safe_name

@router.post("/request-help", status_code=status.HTTP_201_CREATED, response_model=ShowRequest)
def create_request(
    title: str = Form(..., min_length=3, max_length=200),
    description: str = Form(..., min_length=10, max_length=2000),
    location: str = Form(..., min_length=3, max_length=200),
    urgency_level: str = Form("medium"),
    photo: Optional[UploadFile] = File(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)

):
    # Validate urgency level
    valid_urgency_levels = ["low", "medium", "high"]
    if urgency_level not in valid_urgency_levels:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid urgency level. Must be one of: {', '.join(valid_urgency_levels)}"
        )
    
    photo_filename = None
    if photo:
        # Validate file
        validate_file_upload(photo)
        
        # Sanitize filename
        safe_filename = sanitize_filename(photo.filename)
        photo_filename = f"{current_user.id}_{safe_filename}"
        file_path = os.path.join(settings.UPLOAD_DIR, photo_filename)
        
        try:
            with open(file_path, "wb") as buffer:
                
                shutil.copyfileobj(photo.file, buffer)
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to save file: {str(e)}"
            )

    new_request = Request(
        title=title,
        description=description,
        location=location,
        urgency_level=urgency_level,
        photo=photo_filename,
        user_id=current_user.id
    )

    try:
        db.add(new_request)
        db.commit()
        db.refresh(new_request)
        # Add user phone to response
        request_dict = {
            "id": new_request.id,
            "title": new_request.title,
            "description": new_request.description,
            "location": new_request.location,
            "urgency_level": new_request.urgency_level,
            "status": new_request.status,
            "photo": new_request.photo,
            "timestamp": new_request.timestamp,
            "user_id": new_request.user_id,
            "user_phone": current_user.phone_number
        }
        return ShowRequest(**request_dict)
    except Exception as e:
        db.rollback()
        # If file was uploaded, try to clean it up
        if photo_filename:
            try:
                os.remove(os.path.join(settings.UPLOAD_DIR, photo_filename))
            except:
                pass
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create request. Please try again."
        )

# ✅ GET /request - List requests (users see only their own, volunteers see all)
@router.get("/", response_model=List[ShowRequest])
def get_all_requests(
    db: Session = Depends(get_db),
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security)
):
    current_user = None
    if credentials:
        # Use verify_token helper for optional auth
        current_user = verify_token(credentials.credentials, db)
    
    from models import user as user_models
    
    if current_user and current_user.role == "user":
        # Users see only their own requests
        requests = db.query(Request).filter(Request.user_id == current_user.id).all()
    else:
        # Volunteers and unauthenticated see all requests
        requests = db.query(Request).all()
    
    # Add user phone numbers to responses
    result = []
    for req in requests:
        user = db.query(user_models.User).filter(user_models.User.id == req.user_id).first()
        request_dict = {
            "id": req.id,
            "title": req.title,
            "description": req.description,
            "location": req.location,
            "urgency_level": req.urgency_level,
            "status": req.status,
            "photo": req.photo,
            "timestamp": req.timestamp,
            "user_id": req.user_id,
            "user_phone": user.phone_number if user else None
        }
        result.append(ShowRequest(**request_dict))
    return result

# ✅ GET /request/my-requests - Get current user's requests
@router.get("/my-requests", response_model=List[ShowRequest])
def get_my_requests(
    db: Session = Depends(get_db),
    current_user: UserOut = Depends(get_current_user)
):
    from models import user as user_models
    
    requests = db.query(Request).filter(Request.user_id == current_user.id).all()
    
    # Add user phone numbers to responses
    result = []
    for req in requests:
        user = db.query(user_models.User).filter(user_models.User.id == req.user_id).first()
        request_dict = {
            "id": req.id,
            "title": req.title,
            "description": req.description,
            "location": req.location,
            "urgency_level": req.urgency_level,
            "status": req.status,
            "photo": req.photo,
            "timestamp": req.timestamp,
            "user_id": req.user_id,
            "user_phone": user.phone_number if user else None
        }
        result.append(ShowRequest(**request_dict))
    return result

# ✅ GET /request/{id} - Get a single help request by ID
@router.get("/{id}", response_model=ShowRequest)
def get_request(id: int, db: Session = Depends(get_db)):
    from models import user as user_models
    
    help_request = db.query(Request).filter(Request.id == id).first()
    if not help_request:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, 
            detail="Request not found"
        )
    
    # Add user phone to response
    user = db.query(user_models.User).filter(user_models.User.id == help_request.user_id).first()
    request_dict = {
        "id": help_request.id,
        "title": help_request.title,
        "description": help_request.description,
        "location": help_request.location,
        "urgency_level": help_request.urgency_level,
        "status": help_request.status,
        "photo": help_request.photo,
        "timestamp": help_request.timestamp,
        "user_id": help_request.user_id,
        "user_phone": user.phone_number if user else None
    }
    return ShowRequest(**request_dict)

# ✅ GET /request/{id}/volunteers - Get volunteers who applied to a request (only request owner can view)
@router.get("/{id}/volunteers", response_model=List[VolunteerApplicationResponse])
def get_request_volunteers(
    id: int,
    db: Session = Depends(get_db),
    current_user: UserOut = Depends(get_current_user)
):
    """Get all volunteers who applied to help with a specific request (only request owner can view)"""
    help_request = db.query(Request).filter(Request.id == id).first()
    if not help_request:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Request not found"
        )
    
    # Only the request owner can view volunteers
    if help_request.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You can only view volunteers for your own requests"
        )
    
    from models import volunteer_application as vol_models
    from models import user as user_models
    
    applications = db.query(vol_models.VolunteerApplication).filter(
        vol_models.VolunteerApplication.request_id == id
    ).all()
    
    result = []
    for app in applications:
        volunteer = db.query(user_models.User).filter(user_models.User.id == app.volunteer_id).first()
        result.append({
            "id": app.id,
            "volunteer_id": app.volunteer_id,
            "request_id": app.request_id,
            "volunteer_name": volunteer.username if volunteer else "Unknown",
            "volunteer_phone": volunteer.phone_number if volunteer else None,
            "applied_at": app.timestamp
        })
    
    return result